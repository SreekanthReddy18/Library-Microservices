package com.book.app.serviceImpl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.book.app.Dao.BookRepository;
import com.book.app.entity.Book;
import com.book.app.model.BookDto;
import com.book.app.service.BookService;

@Service
public class BookServiceImpl implements BookService {

	@Autowired
	BookRepository bookRepository;

	public Book saveBook(BookDto bookDto) {
		Book book = new Book(bookDto.getId(), bookDto.getName(), bookDto.getPublisher(), bookDto.getAuther());

		Book result = bookRepository.save(book);

		return result;
	}

	public List<Book> getAllBooks() {

		List<Book> bookList = bookRepository.findAll();
		return bookList;
	}

	public Book findById(String id) {
		Optional<Book> book = bookRepository.findById(Long.valueOf(id));

		if (book.isPresent()) {
			return book.get();
		}

		return null;
	}

	public String deleteBookById(String id) {
		bookRepository.deleteById(Long.valueOf(id));
		return id;
	}

	public Book updateBook(BookDto bookDto) {
		Book book = new Book(bookDto.getId(), bookDto.getName(), bookDto.getPublisher(), bookDto.getAuther());

		Book result = bookRepository.save(book);

		return result;
	}

}
