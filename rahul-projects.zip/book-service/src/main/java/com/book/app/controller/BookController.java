package com.book.app.controller;

import java.security.Principal;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.TreeMap;

import javax.servlet.http.HttpServletRequest;
import javax.websocket.server.PathParam;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import com.book.app.entity.Book;
import com.book.app.model.BookDto;
import com.book.app.service.BookService;
import com.paytm.pg.merchant.PaytmChecksum;

@RestController
@RequestMapping("/book")
public class BookController {

  

   @Autowired
   BookService bookServiceImpl;
	
	@GetMapping("/test")
	public String home() {
		return "home";
	}

	@PostMapping(value = "/save")
	public ResponseEntity<Book> saveBook(@RequestBody BookDto bookDto) throws Exception {

		
		return new ResponseEntity(bookServiceImpl.saveBook(bookDto), HttpStatus.CREATED);
	}
	
	@PutMapping(value = "/update")
	public ResponseEntity<Book> updateBook(@RequestBody BookDto bookDto) throws Exception {

		
		return new ResponseEntity(bookServiceImpl.updateBook(bookDto), HttpStatus.CREATED);
	}
	
	@GetMapping(value="/getAll")
    public ResponseEntity<List<Book>> getAllBooks(){
		return new ResponseEntity(bookServiceImpl.getAllBooks(), HttpStatus.OK);
		
	}
	
	@GetMapping(value="/getbooks/byid/{id}")
    public ResponseEntity<Book> findBooksById(@PathVariable String id){
		return new ResponseEntity(bookServiceImpl.findById(id), HttpStatus.OK);
		
	}
	
	@DeleteMapping(value="/deletebooks/byid/{id}")
    public ResponseEntity<String> deleteBooksById(@PathVariable String id){
		String success=bookServiceImpl.deleteBookById(id);
		return new ResponseEntity(success, HttpStatus.OK);
		
	}
	
}
