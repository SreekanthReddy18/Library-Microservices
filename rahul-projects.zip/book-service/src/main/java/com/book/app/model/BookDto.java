package com.book.app.model;



public class BookDto {
	
    private Long id;
	
	private String name;
	
	private String publisher;
	
	private String auther;
	
	public BookDto() {
	}

	public BookDto(Long id, String name, String publisher, String auther) {
		this.id = id;
		this.name = name;
		this.publisher = publisher;
		this.auther = auther;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPublisher() {
		return publisher;
	}

	public void setPublisher(String publisher) {
		this.publisher = publisher;
	}

	public String getAuther() {
		return auther;
	}

	public void setAuther(String auther) {
		this.auther = auther;
	}

	@Override
	public String toString() {
		return "BookDto [id=" + id + ", name=" + name + ", publisher=" + publisher + ", auther=" + auther + "]";
	}
	
}
