package com.book.app.service;

import java.util.List;

import com.book.app.entity.Book;
import com.book.app.model.BookDto;

public interface BookService {

	public Book saveBook(BookDto bookDto);
	
    public List<Book> getAllBooks();
	
    public Book findById(String id);
	
	public String deleteBookById(String id);
	
	public Book updateBook(BookDto bookDto);
}
