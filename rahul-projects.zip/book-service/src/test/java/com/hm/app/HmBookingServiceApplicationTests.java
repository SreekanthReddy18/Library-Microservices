package com.hm.app;

import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HmBookingServiceApplicationTests {


}
