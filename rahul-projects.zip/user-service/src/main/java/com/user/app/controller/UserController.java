package com.user.app.controller;

import java.util.List;

import com.user.app.entity.User;
import com.user.app.model.*;
import com.user.app.service.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/user")
public class UserController {

  

	   @Autowired
	   UserService userServiceImpl;
		
		@GetMapping("/test")
		public String home() {
			return "home";
		}

		@PostMapping(value = "/save")
		public ResponseEntity<User> saveUser(@RequestBody UserDto userDto) throws Exception {

			
			return new ResponseEntity(userServiceImpl.saveUser(userDto), HttpStatus.CREATED);
		}
		
		@PutMapping(value = "/update")
		public ResponseEntity<User> updateUser(@RequestBody UserDto userDto) throws Exception {

			
			return new ResponseEntity(userServiceImpl.updateUser(userDto), HttpStatus.CREATED);
		}
		
		@GetMapping(value="/getAll")
	    public ResponseEntity<List<User>> getAllUsers(){
			return new ResponseEntity(userServiceImpl.getAllUsers(), HttpStatus.OK);
			
		}
		
		@GetMapping(value="/getuser/byid/{id}")
	    public ResponseEntity<User> findUserById(@PathVariable String id){
			return new ResponseEntity(userServiceImpl.findById(id), HttpStatus.OK);
			
		}
		
		@DeleteMapping(value="/deleteuser/byid/{id}")
	    public ResponseEntity<String> deleteUserById(@PathVariable String id){
			String success=userServiceImpl.deleteUserById(id);
			return new ResponseEntity(success, HttpStatus.OK);
			
		}
}
