package com.user.app.serviceImpl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.user.app.Dao.UserRepository;
import com.user.app.entity.User;
import com.user.app.model.UserDto;
import com.user.app.service.UserService;

@Service
public class UserServiceImpl implements UserService{

	@Autowired
	UserRepository userRepository;
	
	public User saveUser(UserDto userDto) {
		User user = new User(userDto.getId(),userDto.getUserName() ,userDto.getEmail(), userDto.getName());

		User result = userRepository.save(user);

		return result;
	}

	public List<User> getAllUsers() {

		List<User> userList = userRepository.findAll();
		return userList;
	}

	public User findById(String id) {
		Optional<User> user = userRepository.findById(Long.valueOf(id));

		if (user.isPresent()) {
			return user.get();
		}

		return null;
	}

	public String deleteUserById(String id) {
		userRepository.deleteById(Long.valueOf(id));
		return id;
	}

	public User updateUser(UserDto userDto) {
		User user = new User(userDto.getId(),userDto.getUserName() ,userDto.getEmail(), userDto.getName());

		User result = userRepository.save(user);

		return result;
	}

}
