package com.user.app.service;

import java.util.List;

import com.user.app.entity.User;
import com.user.app.model.UserDto;

public interface UserService {

	public User saveUser(UserDto userDto);
	
    public List<User> getAllUsers();
	
    public User findById(String id);
    
    public User updateUser(UserDto userDto);
	
	public String deleteUserById(String id);
}
