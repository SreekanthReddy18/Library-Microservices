//package com.hm.app;
//
//import org.junit.jupiter.api.Test;
//import org.springframework.boot.test.context.SpringBootTest;
//
//@SpringBootTest
//class HmMasterServiceApplicationTests {
//
//	@Test
//	void contextLoads() {
//	}
//
//}
