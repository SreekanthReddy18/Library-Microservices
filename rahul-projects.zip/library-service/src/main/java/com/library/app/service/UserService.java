package com.library.app.service;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.library.app.entity.User;
import com.library.app.model.UserDto;

@FeignClient(url = "http://localhost:8082",name="user-service")
public interface UserService {
	
	@PostMapping(value = "/user/save")
	public ResponseEntity<User> saveUser(@RequestBody UserDto userDto) throws Exception;
	
	@PutMapping(value = "/user/update")
	public ResponseEntity<User> updateUser(@RequestBody UserDto userDto) throws Exception;
	
	@GetMapping(value="/user/getAll")
    public ResponseEntity<List<User>> getAllUsers();
	
	@GetMapping(value="/user/getuser/byid/{id}")
    public ResponseEntity<User> findUserById(@PathVariable String id);
	
	@DeleteMapping(value="/user/deleteuser/byid/{id}")
    public ResponseEntity<String> deleteUserById(@PathVariable String id);

}
