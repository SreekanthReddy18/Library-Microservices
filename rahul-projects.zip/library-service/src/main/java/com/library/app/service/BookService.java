package com.library.app.service;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.library.app.entity.Book;
import com.library.app.model.BookDto;

@FeignClient(url = "http://localhost:8081",name="book-service")
public interface BookService {
	
	

	@PostMapping(value = "/book/save")
	public ResponseEntity<Book> saveBook(@RequestBody BookDto bookDto) throws Exception;
	
	@PutMapping(value = "/book/update")
	public ResponseEntity<Book> updateBook(@RequestBody BookDto bookDto) throws Exception;
	
	@GetMapping(value="/book/getAll")
    public ResponseEntity<List<Book>> getAllBooks();
	
	@GetMapping(value="/book/getbooks/byid/{id}")
    public ResponseEntity<Book> findBooksById(@PathVariable String id);
	
	@DeleteMapping(value="/book/deletebooks/byid/{id}")
    public ResponseEntity<String> deleteBooksById(@PathVariable String id);

	
}
