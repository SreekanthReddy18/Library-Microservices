package com.library.app.controller;


import java.util.List;


import com.library.app.entity.Book;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.library.app.model.*;
import com.library.app.service.*;
import com.library.app.entity.User;
import com.library.app.model.UserDto;

@RestController
@RequestMapping("/library")
public class LibraryController {

	@Autowired
	BookService bookServiceImpl;

	@Autowired
	UserService userServiceImpl;

	@ExceptionHandler(value = Exception.class)
	public ResponseEntity<Object> exception(Exception e) {

		return new ResponseEntity<>(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
	}

	@GetMapping("/test")
	public String home() {
		return "home";
	}

	@PostMapping(value = "/book/save")
	public ResponseEntity<Book> saveBook(@RequestBody BookDto bookDto) throws Exception {

		return new ResponseEntity(bookServiceImpl.saveBook(bookDto), HttpStatus.CREATED);
	}

	@PutMapping(value = "/book/update")
	public ResponseEntity<Book> updateBook(@RequestBody BookDto bookDto) throws Exception {

		return new ResponseEntity(bookServiceImpl.updateBook(bookDto), HttpStatus.CREATED);
	}

	@GetMapping(value = "/book/getAll")
	public ResponseEntity<List<Book>> getAllBooks() {
		return new ResponseEntity(bookServiceImpl.getAllBooks(), HttpStatus.OK);

	}

	@GetMapping(value = "/getbooks/byid/{id}")
	public ResponseEntity<Book> findBooksById(@PathVariable String id) {
		return new ResponseEntity(bookServiceImpl.findBooksById(id), HttpStatus.OK);

	}

	@DeleteMapping(value = "/deletebooks/byid/{id}")
	public ResponseEntity<String> deleteBooksById(@PathVariable String id) {
		return new ResponseEntity(bookServiceImpl.deleteBooksById(id), HttpStatus.OK);

	}
	
	@PostMapping(value = "/user/save")
	public ResponseEntity<User> saveUser(@RequestBody UserDto userDto) throws Exception {

		
		return new ResponseEntity(userServiceImpl.saveUser(userDto), HttpStatus.CREATED);
	}
	
	@PutMapping(value = "/user/update")
	public ResponseEntity<User> updateUser(@RequestBody UserDto userDto) throws Exception {

		
		return new ResponseEntity(userServiceImpl.updateUser(userDto), HttpStatus.CREATED);
	}
	
	@GetMapping(value="/user/getAll")
    public ResponseEntity<List<User>> getAllUsers(){
		return new ResponseEntity(userServiceImpl.getAllUsers(), HttpStatus.OK);
		
	}
	
	@GetMapping(value="/getuser/byid/{id}")
    public ResponseEntity<User> findUserById(@PathVariable String id){
		return new ResponseEntity(userServiceImpl.findUserById(id), HttpStatus.OK);
		
	}
	
	@DeleteMapping(value="/deleteuser/byid/{id}")
    public ResponseEntity<String> deleteUserById(@PathVariable String id){
		return new ResponseEntity(userServiceImpl.deleteUserById(id), HttpStatus.OK);
		
	}


}
